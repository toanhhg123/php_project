<?php
  define('SESSION_CARTS', 'cartsSession');
  define('SESSION_PRODUCTS', 'products');
  define('SESSION_AUTH', 'AUTH_SESSION');

?>