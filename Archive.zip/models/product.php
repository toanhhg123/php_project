<?php
require_once 'constants/define.php';
require_once('service/productService.php');
?>
<?php
if (!isset($_SESSION)) {
    session_start();
}
?>
<?php
class Product
{

    public $id;
    public $name;
    public $price;
    public $image;


    public function __construct($id, $name, $price, $image)
    {
        $this->name = $name;
        $this->id = $id;
        $this->price = $price;
        $this->image = $image;
    }

    /**
     * @return Product[]
     */
    public static function findAll(): array
    {
        $data = $_SESSION[SESSION_PRODUCTS] ?? GetAllProduct();
        if (!isset($_SESSION[SESSION_PRODUCTS]))
            $_SESSION[SESSION_PRODUCTS] = $data;
        return unserialize(serialize($_SESSION[SESSION_PRODUCTS]));
    }

    public static function findById($id): ?Product
    {
        $arr = Product::findAll();
        $key = array_search($id, array_column($arr, 'id'));
        return $arr[$key] ?? null;
    }
}
